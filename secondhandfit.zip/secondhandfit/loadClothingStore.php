<?php
include "DBConn.php";

// DROP TABLES
$conn->query("DROP TABLE IF EXISTS tblUser");
$conn->query("DROP TABLE IF EXISTS tblAdmin");

// CREATE tblUser
$conn->query("CREATE TABLE tblUser (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(255),
    status VARCHAR(20)
)");

// CREATE tblAdmin
$conn->query("CREATE TABLE tblAdmin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255)
)");

echo "Tables created successfully!";
?>